﻿Public Class cetaklaporanrundis
    Private Sub cetaklaporanrundis_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CrystalReportViewer1.RefreshReport()
    End Sub
End Class