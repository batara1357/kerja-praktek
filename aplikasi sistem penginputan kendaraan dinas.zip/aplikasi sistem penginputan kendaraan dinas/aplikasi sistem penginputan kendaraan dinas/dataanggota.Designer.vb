﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dataanggota
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.ComboBox1)
        Me.GroupBox1.Controls.Add(Me.TextBox2)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.DataGridView1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 51)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(797, 160)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(194, 122)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "HAPUS"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(100, 122)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "EDIT"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(7, 122)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "SIMPAN"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ComboBox1
        '
        Me.ComboBox1.BackColor = System.Drawing.SystemColors.Window
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Asintel Pangkolinlamil", "Askomlek Pangkolinlamil", "Aslog Pangkolinlamil", "Asops Pangkolinlamil", "Aspers Pangkolinlamil", "Aspotmar Pangkolinlamil", "Asrena Pangkolinlamil", "BAMA KRI BAC-593", "Bama KRI BJM-592", "Bama KRI KBI-971", "Bama KRI TBN-520", "Bama KRI THG-538", "DAN KRI 1H0-530", "DAN KRI ABN-503", "DAN KRI BAC-693", "DAN KRI BJM-592", "DAN KRI KBI-971", "DAN KRI MTW. 050", "DAN KRI TG1-539", "DAN KRI TLP-540", "DAN KRITON-620", "Dandenmako", "Dansatantamil 2", "Dansatlinlamil 1", "Dansatlinlamil 2", "Dansatlinlamil 3", "Diskes l", "Irben Inspektorat", "Irkolinlamil", "Irops Irkolinlamil", "Irum Inspektorat ", "Jalasonastri Cob", "Ka Akun Mako ", "Ka Posmil Setum ", "Kadeps in KRI MTV-959", "Kadepsin KRI ABN-503", "Kadepsin KRI BAC 593", "Kadepsin KRI THG-538", "Kadepsin KRI TLP 540", "Kadepsin KRI TMO-537", "Kadepsin KRIKBI-971", "Kadepsio KRI TG1-539", "Kadisharkap ", "Kadisinfolahta ", "Kadiskomlek ", "Kadiskum ", "Kadismatbek ", "Kadisminpers ", "Kadispen ", "Kadorism KNI BJM S", "Kakuwil ", "Kapuskodal ", "Kas ", "Kasatang Denmako", "Kasatbek Denmako", "Kasatharkan Satlinlamil", "Kasatkom Diskomlek", "Kasetum Kolinlamil", "Kasubdis Dalminku", "Kasubdis Harplatform", "Kasubdis Sewaco", "Kasubdisren Disharkap", "Kasubsiyar Akun Mako", "Katerminal Satlinfamil 1", "Kaur TU Diskum ", "Kediaman Pangkolinlamil", "Komandan POM ", "Koorsmin ", "Mobil Kawal Pomal", "Mobil PCR Fastlab", "Mobil Pendukung", "Motor Kawal Pomal", "Nasor KRI TBN-520", "Operasional", "Ops Bama Denmako (K)", "Ops Diskum ", "Ops Dispen ", "Ops IV jalasenastn", "Ops Koorsmin ", "Ops KRI Banda Aceh-593", "Ops Kuwil ", "Ops PG Jalasenastri", "Ops Satharkan Satlinfamil 2", "Ops Set Satlintamil 2", "Ops Slog Kolinlamil", "Ops Smin Safinlamil 2", "Ops Sops ", "Ops Srena ", "Ops. Bek Satliniam/f'2", "Ops. Proga Sallinlamil 2", "Ops. Provast Satliniamil 2", "Ops. Setum ", "Ops Akun Saflintamil 2", "Ordonan KRI BAC-593", "Ordonan KRI BUM-592", "Ordonan KRI KBI-971", "Ordonan KRI THG-538", "Ordonan KRI TMO-537", "Ordonan Satlinlamil", "Ordonan Setum", "Ordonan Setum ", "Paban Bek Slog ", "Paban Dalangkanas Sops", "Paban Fasjas Slog ", "Paban Har Slog ", "Paban Jian Srena ", "Paban Lermar Sintel", "Paban Ops Kolinlamil", "Paban Ren Sintel ", "Paban Ren Slog ", "Paban Ren Spers ", "Paban Renpuan", "Pabandya Becka Slog", "Pabandya Opsga Sops", "Palaksa KRI (JM 592", "Palaksa KRI ABN-500", "Palaksa KRI BAC-593", "Palaksa KRI KBI-971", "Palaksa KRI MTV-959", "Palaksa KRI TG1-539", "Palaksa KRI THG -539", "Palaksa KRI TLP-540", "Palakso KRI TMO,537", "Palaria KRI TRI", "Pangkolinlamil", "Pasmin Denmako Kolinlamil", "Pasminiog Satliniamil 2", "Pasminlog Satlinlamil", "Pasops Satliniamil 2", "Patwal Provost", "Pelaksa Denmako", "Penanting / Jaga Denmako (K)", "Pengemudi Pangkolinlamil", "Pool Satlinlamil 3", "Primkopal Satlinlamil 2", "Protokoler Kolinlamil 1", "Protokoler Saftiniami 1", "Protokoler Salliniamil 2", "Satang Denmako (k) / Lyn", "Satang Denmako ", "Satma / Dinas Penanting", "Supir aslog Pangkolinlamil", "Terminal Salliniamil 1", "Terminal Satlinlamil 3", "Urpandu Satlinlamil", "Vip Satang Denmako (k1)", "Vip Satang Denmako (k2)", "Vip Satang Denmako (k3)", "Vip Satang Denmako (k4)", "Vip Satang Denmako (k5)", "Wadah Satlinlamil 3", "Wadan Satlinlamil", "Wakil Ketua PG"})
        Me.ComboBox1.Location = New System.Drawing.Point(113, 77)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(156, 21)
        Me.ComboBox1.TabIndex = 6
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(114, 47)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(155, 20)
        Me.TextBox2.TabIndex = 5
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(114, 20)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(155, 20)
        Me.TextBox1.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Location = New System.Drawing.Point(7, 77)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "satker"
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Location = New System.Drawing.Point(7, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Nama"
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Location = New System.Drawing.Point(7, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Nrp"
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(275, 19)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(516, 126)
        Me.DataGridView1.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Location = New System.Drawing.Point(287, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 23)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Search"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(349, 28)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(155, 20)
        Me.TextBox3.TabIndex = 10
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(510, 28)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(31, 23)
        Me.Button4.TabIndex = 10
        Me.Button4.Text = "GO"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'dataanggota
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(821, 266)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "dataanggota"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "dataanggota"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Button4 As Button
End Class
